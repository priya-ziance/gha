import { H2 } from '@blueprintjs/core';

const CustomH2 = (props: any) => {
  return (
    <H2 {...props} />
  )
}

export default CustomH2;

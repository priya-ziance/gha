import { H1 } from '@blueprintjs/core';

const CustomH1 = (props: any) => {
  return (
    <H1 {...props} />
  )
}

export default CustomH1;

export const EXPENSE_ACCOUNT_TYPES = {
  normal: 'Normal',
  recurring: 'Recurring'
};

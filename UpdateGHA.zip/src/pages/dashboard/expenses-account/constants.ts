export const EXPENSE_ACCOUNT_TYPES = {
  main_account: 'Main Account',
  personal_funds: 'Personal Funds'
};

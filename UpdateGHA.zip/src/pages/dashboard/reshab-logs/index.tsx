import LogEntry from "../_component-pages/log-entry";

const ReshabLogs = () => {
  return (
    <LogEntry type='reshab'/>
  )
}

export default ReshabLogs;
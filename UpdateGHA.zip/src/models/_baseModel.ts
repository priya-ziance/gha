export default interface BaseModel {
  id: string;
}
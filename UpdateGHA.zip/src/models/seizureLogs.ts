import IBaseModel from "./_baseModel";
import moment, { Moment } from "moment";
import { ISeizurelogs } from "../types";

export default class Seizurelogs implements IBaseModel {
  time?: string;
  emp_id: string;
  date?: Moment;
  notes?: string;
  email?: string;
  active?: boolean;
  duration?: string;
  activity_preceding?: String
  Injuries?: string
  patient_have_seizure?: string
  seizurelogs: ISeizurelogs;

  constructor(seizurelogs: ISeizurelogs) {
    this.time = seizurelogs.time;
    this.emp_id = seizurelogs.emp_id;
    this.date = seizurelogs.date
    ? moment(seizurelogs.date)
    : undefined;
    this.notes = seizurelogs.notes;
    this.time = seizurelogs.time;
    this.Injuries = seizurelogs.Injuries;
    this.activity_preceding = seizurelogs.activity_preceding
    this.duration = seizurelogs.duration
    this.active =seizurelogs.active
    this.seizurelogs = seizurelogs;
    this.patient_have_seizure = seizurelogs.patient_have_seizure
  }
}

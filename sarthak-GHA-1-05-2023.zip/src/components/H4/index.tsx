import { H4 } from '@blueprintjs/core';

const CustomH4 = (props: any) => {
  return (
    <H4 {...props} />
  )
}

export default CustomH4;

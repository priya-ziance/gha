import { H3 } from '@blueprintjs/core';

const CustomH3 = (props: any) => {
  return (
    <H3 {...props} />
  )
}

export default CustomH3;

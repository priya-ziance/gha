import LogEntry from "../_component-pages/log-entry";

const PersonalSupportLogs = () => {
  return (
    <LogEntry type='personalsupport' />
  )
}

export default PersonalSupportLogs;
import LogEntry from "../_component-pages/log-entry";

const LifeSkillsLogs = () => {
  return (
    <LogEntry type='lifeskills' />
  )
}

export default LifeSkillsLogs;
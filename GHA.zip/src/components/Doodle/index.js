/* doodle.js */

import 'css-doodle';

export default ({ rule = '' }) => (
  <css-doodle>{ rule }</css-doodle>
)
// This solves the typing issue for react-signature-pad-wrapper

declare module '*';
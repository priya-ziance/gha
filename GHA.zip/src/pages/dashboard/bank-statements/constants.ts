export const BANK_STATEMENT_TYPES = {
  main_account: 'Main Account',
  personal_funds: 'Personal Funds'
};

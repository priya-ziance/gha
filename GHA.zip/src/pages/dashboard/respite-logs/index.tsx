import LogEntry from "../_component-pages/log-entry";

const RespiteLogs = () => {
  return (
    <LogEntry type='respite' />
  )
}

export default RespiteLogs;